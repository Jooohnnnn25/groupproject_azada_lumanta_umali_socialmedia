package com.groupproject_azada_lumanta_umali.groupproject_azada_lumanta_umali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupprojectAzadaLumantaUmaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupprojectAzadaLumantaUmaliApplication.class, args);
	}

}
