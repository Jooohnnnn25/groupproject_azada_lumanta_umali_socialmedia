package com.groupproject_azada_lumanta_umali.groupproject_azada_lumanta_umali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupprojectAzadaLumantaUmaliApplicationTests {

	@Test
	void contextLoads() {
	}

}
